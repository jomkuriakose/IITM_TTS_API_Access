python3 IITM_TTS_API_Files_Parallel_v2.py -h
usage: IITM_TTS_API_Files_Parallel_v2.py [-h] -i INPUT_FILENAME -o
                                         OUTPUT_FOLDERNAME -l LANGUAGE -g
                                         GENDER

TTS using API synthesis code

Author: Jom Kuriakose
email: jom@cse.iitm.ac.in
Date: 09/11/2022

Example: python3 IITM_TTS_API_Files_Parallel_v2.py -i input_text_file.txt -o output_folder_name -l Hindi -g male
This synthesizes the text in input_text_file.txt and saves each line as .wav file in output_folder.

optional arguments:
  -h, --help            show this help message and exit
  -i INPUT_FILENAME, --input_filename INPUT_FILENAME
                        Input file name
  -o OUTPUT_FOLDERNAME, --output_foldername OUTPUT_FOLDERNAME
                        Output folder name
  -l LANGUAGE, --language LANGUAGE
                        TTS language
  -g GENDER, --gender GENDER
                        TTS gender
                        
